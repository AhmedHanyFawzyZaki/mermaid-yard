<?php
/*
|--------------------------------------------------------------------------
| Translation file - Spanish
|--------------------------------------------------------------------------
|
| NOTE, this file must be saved in UTF-8 encoding.
*/
return array (
	'bad' => 'mal',
	'poor' => 'flojo',
	'regular' => 'regular',
	'good' => 'bien',
	'gorgeous' => 'excelente',
	'Not rated yet!' => 'No votado',
	'Cancel this rating!' => 'Cancelar este voto',
);